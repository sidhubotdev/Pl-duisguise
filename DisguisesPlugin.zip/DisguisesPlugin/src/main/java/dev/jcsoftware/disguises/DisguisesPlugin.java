package dev.jcsoftware.disguises;

import dev.jcsoftware.disguises.commands.DisguiseCommand;
import dev.jcsoftware.disguises.listener.DisguiseListener;
import dev.jcsoftware.disguises.utility.HTTPUtility;
import org.bukkit.plugin.java.JavaPlugin;

public final class DisguisesPlugin extends JavaPlugin {
  private DisguiseManager disguiseManager;

  @Override
  public void onEnable() {
    HTTPUtility httpUtility = new HTTPUtility(this);
    this.disguiseManager = new DisguiseManager(this, httpUtility);

    getCommand("disguise")
        .setExecutor(new DisguiseCommand(disguiseManager));

    getServer().getPluginManager()
        .registerEvents(new DisguiseListener(disguiseManager), this);
  }
}
